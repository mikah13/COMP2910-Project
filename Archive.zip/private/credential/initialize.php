<?php
    ob_start();
    require_once('database.php');
    $conn = db_connect();

?>
