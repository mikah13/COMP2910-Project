<?php
    require_once('assets/php/session.php');
 ?>


 <?php
    db_disconnect($conn);
 ?>
